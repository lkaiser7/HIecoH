Infiltration Data

Fortini Data
Infiltration rates of mesic and wet forests
v2_Ecohydrology_model_inputs_DR.csv [hiecoh_ALL_DATA.csv]
hiecoh_master_data_file_metadata.csv

Perkins Data
Meta analysis compiling infiltration data statewide
perkins_Hawaii_infiltration_data_summary.xls

PROCESSED DATA
/kfs_data/
Manually formatted for infiltration analysis
hiecoh_kp_data.csv
hiecoh_lf_data.csv

Final Output: hiecoh_kfsdata.csv